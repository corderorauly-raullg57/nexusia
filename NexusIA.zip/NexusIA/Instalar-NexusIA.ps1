﻿# ==========================================================
#  INSTALADOR DE NexusIA  ·  by HiSpaNet
#  Instala NexusIA y, si eliges, su motor gratis (FreeLLMAPI)
#  y la IA sin Internet (Ollama + modelo gemma3).
# ==========================================================
$ErrorActionPreference = "Continue"
$Host.UI.RawUI.WindowTitle = "Instalador de NexusIA"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$origen  = Split-Path -Parent $MyInvocation.MyCommand.Path
$destino = Join-Path $env:LOCALAPPDATA "NexusIA"
$tmp     = Join-Path $env:TEMP "NexusIA-instalador"
New-Item -ItemType Directory -Force -Path $destino, $tmp | Out-Null
try { Start-Transcript -Path (Join-Path $destino "instalacion.log") -Append | Out-Null } catch {}

function Titulo([string]$t) { Write-Host ""; Write-Host ("=" * 62) -ForegroundColor DarkYellow; Write-Host "  $t" -ForegroundColor Yellow; Write-Host ("=" * 62) -ForegroundColor DarkYellow }
function Ok([string]$t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Info([string]$t) { Write-Host "  $t" }
function Aviso([string]$t){ Write-Host "  [!] $t" -ForegroundColor Yellow }
function Pausa([string]$t = "Pulsa Enter para continuar") { Read-Host "  $t" | Out-Null }

function Descargar([string]$url, [string]$archivo, [string]$nombre) {
  for ($i = 1; $i -le 3; $i++) {
    Info "Descargando $nombre (intento $i de 3)... si se corta, se reanuda."
    try {
      Import-Module BitsTransfer -ErrorAction Stop
      Start-BitsTransfer -Source $url -Destination $archivo -DisplayName "NexusIA: $nombre" -Priority Foreground -ErrorAction Stop
      if ((Test-Path $archivo) -and (Get-Item $archivo).Length -gt 1MB) { Ok "$nombre descargado"; return $true }
    } catch {
      try {
        $ProgressPreference = "Continue"
        Invoke-WebRequest -Uri $url -OutFile $archivo -UseBasicParsing -ErrorAction Stop
        if ((Test-Path $archivo) -and (Get-Item $archivo).Length -gt 1MB) { Ok "$nombre descargado"; return $true }
      } catch { Aviso ("No se pudo descargar: " + $_.Exception.Message) }
    }
    Start-Sleep -Seconds 5
  }
  return $false
}
function Ruta-FreeLLMAPI {
  foreach ($r in "$env:LOCALAPPDATA\Programs\FreeLLMAPI\FreeLLMAPI.exe", "$env:LOCALAPPDATA\Programs\freellmapi\FreeLLMAPI.exe", "$env:ProgramFiles\FreeLLMAPI\FreeLLMAPI.exe") { if (Test-Path $r) { return $r } }
  $l = Get-ChildItem "$env:APPDATA\Microsoft\Windows\Start Menu\Programs", "$env:USERPROFILE\Desktop" -Recurse -Include "*.lnk" -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "free\s*llm" } | Select-Object -First 1
  if ($l) { return $l.FullName }
  return $null
}
function Ruta-Ollama { $r = "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe"; if (Test-Path $r) { return $r }; $c = Get-Command ollama -ErrorAction SilentlyContinue; if ($c) { return $c.Source }; return $null }

# ---------------------------------------------------------- bienvenida
Clear-Host
Titulo "Bienvenido al instalador de NexusIA"
Info "NexusIA es tu centro de agentes de IA: chat, agentes para tu negocio,"
Info "documentos, imágenes y comparador. Este instalador lo deja listo."
Info ""
$ramGB = 0; $discoGB = 0
try { $ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB) } catch {}
try { $discoGB = [math]::Round((Get-PSDrive ($env:SystemDrive.TrimEnd(":"))).Free / 1GB) } catch {}
Info "Tu computadora:  memoria RAM $ramGB GB  ·  espacio libre $discoGB GB"
$puedeCompleto = ($ramGB -ge 8) -and ($discoGB -ge 8)

Titulo "Elige el tipo de instalación"
Write-Host ""
Write-Host "  [1] LIGERO  (recomendado para la mayoría)" -ForegroundColor Cyan
Info "      Instala NexusIA + FreeLLMAPI (unos 110 MB de descarga)."
Info "      Te da cientos de IA gratis de Internet que se turnan solas"
Info "      cuando una gasta su crédito del día."
Info "      Necesita conexión a Internet para trabajar."
Write-Host ""
Write-Host "  [2] COMPLETO  (también funciona SIN Internet)" -ForegroundColor Cyan
Info "      Todo lo del LIGERO + Ollama + el modelo gemma3 (unos 4,5 GB)."
Info "      Cuando no hay Internet, sigue respondiendo con la IA de tu PC"
Info "      (más lenta). Necesita 8 GB de RAM o más y 8 GB libres."
Write-Host ""
Write-Host "  [3] SOLO NexusIA  (no descarga nada más)" -ForegroundColor Cyan
Info "      Para probar o si no puedes descargar ahora. Usarás claves"
Info "      gratis puestas directamente en NexusIA (Gemini, Groq...)."
Info "      Puedes volver a ejecutar este instalador más tarde."
Write-Host ""
if ($puedeCompleto) { Write-Host "  Tu PC puede usar el COMPLETO. Si tu Internet es lento o caro, empieza por el LIGERO." -ForegroundColor Green }
else { Write-Host "  Para tu PC recomendamos el LIGERO (el COMPLETO necesita 8 GB de RAM y 8 GB libres)." -ForegroundColor Green }
Write-Host ""
# Si el técnico dejó recomendada una opción (archivo opcion.txt), se propone por defecto
$sug = ""
try { $sf = Join-Path $origen "opcion.txt"; if (Test-Path $sf) { $sug = ((Get-Content $sf -Raw) -replace "[^123]", "").Substring(0, 1) } } catch { $sug = "" }
if ($sug) {
  $nom = @{ "1" = "LIGERO"; "2" = "COMPLETO"; "3" = "SOLO NexusIA" }[$sug]
  Write-Host "  Tu técnico te recomienda la opción [$sug] $nom. Pulsa Enter para usarla." -ForegroundColor Yellow
}
do { $op = (Read-Host "  Escribe 1, 2 o 3 y pulsa Enter").Trim(); if (-not $op -and $sug) { $op = $sug } } while ($op -notin "1", "2", "3")
if ($op -eq "2" -and -not $puedeCompleto) {
  Aviso "Tu PC tiene menos memoria o espacio del recomendado. Puede ir muy lento."
  $c = Read-Host "  ¿Continuar con el COMPLETO igualmente? (s/n)"
  if ($c -notmatch "^[sS]") { $op = "1" }
}

# ---------------------------------------------------------- 1. NexusIA
Titulo "Paso 1 · Instalando NexusIA"
$app = Join-Path $origen "app"
if (-not (Test-Path (Join-Path $app "nexus-ia.html"))) { $app = $origen }
Copy-Item -Path (Join-Path $app "*") -Destination $destino -Recurse -Force -Exclude "Instalar*"
Ok "NexusIA copiada en $destino"
try {
  $ws = New-Object -ComObject WScript.Shell
  $ico = Join-Path $destino "nexusia.ico"
  foreach ($lnk in (Join-Path ([Environment]::GetFolderPath("Desktop")) "NexusIA.lnk"), (Join-Path ([Environment]::GetFolderPath("Programs")) "NexusIA.lnk")) {
    $s = $ws.CreateShortcut($lnk)
    $s.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $s.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File `"$destino\Abrir-NexusIA.ps1`""
    $s.WorkingDirectory = $destino
    if (Test-Path $ico) { $s.IconLocation = $ico }
    $s.Description = "NexusIA - centro de agentes de IA"
    $s.Save()
  }
  Ok "Icono «NexusIA» creado en el escritorio y en el menú Inicio"
} catch { Aviso "No pude crear el icono. Abre NexusIA con «Abrir NexusIA.bat» en $destino" }

# ---------------------------------------------------------- 2. FreeLLMAPI
if ($op -in "1", "2") {
  Titulo "Paso 2 · Motor gratis: FreeLLMAPI"
  $fl = Ruta-FreeLLMAPI
  if ($fl) { Ok "FreeLLMAPI ya estaba instalado" }
  else {
    $url = $null
    try {
      $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/tashfeenahmed/freellmapi/releases/latest" -Headers @{ "User-Agent" = "NexusIA-instalador" } -UseBasicParsing
      $asset = $rel.assets | Where-Object { $_.name -match "Setup.*\.exe$" } | Select-Object -First 1
      if ($asset) { $url = $asset.browser_download_url; Info ("Versión encontrada: " + $rel.tag_name) }
    } catch { Aviso "No pude consultar la última versión en GitHub." }
    $exe = Join-Path $tmp "FreeLLMAPI-Setup.exe"
    if ($url -and (Descargar $url $exe "FreeLLMAPI")) {
      Info "Instalando FreeLLMAPI (espera un minuto)..."
      Start-Process -FilePath $exe -ArgumentList "/S" -Wait
      Start-Sleep -Seconds 3
      $fl = Ruta-FreeLLMAPI
      if ($fl) { Ok "FreeLLMAPI instalado" } else { Aviso "El instalador terminó pero no encuentro FreeLLMAPI. Si se abrió una ventana de instalación, complétala." }
    }
    if (-not $fl) {
      Aviso "Instálalo a mano: se abrirá la página de descargas."
      Info  "Descarga el archivo que termina en «Setup ... .exe», ábrelo y sigue los pasos."
      Info  "Si Windows avisa «Windows protegió su PC»: Más información > Ejecutar de todas formas."
      Start-Process "https://github.com/tashfeenahmed/freellmapi/releases/latest"
      Pausa "Cuando termines de instalarlo, pulsa Enter"
      $fl = Ruta-FreeLLMAPI
    }
  }
  if ($fl) { Info "Abriendo FreeLLMAPI..."; Start-Process $fl }
}

# ---------------------------------------------------------- 3. Ollama + modelo
if ($op -eq "2") {
  Titulo "Paso 3 · IA sin Internet: Ollama + gemma3"
  $ol = Ruta-Ollama
  if ($ol) { Ok "Ollama ya estaba instalado" }
  else {
    $exe = Join-Path $tmp "OllamaSetup.exe"
    if (Descargar "https://ollama.com/download/OllamaSetup.exe" $exe "Ollama") {
      Info "Instalando Ollama (puede tardar un par de minutos)..."
      Start-Process -FilePath $exe -ArgumentList "/VERYSILENT", "/NORESTART", "/SUPPRESSMSGBOXES" -Wait
      Start-Sleep -Seconds 5
      $ol = Ruta-Ollama
    }
    if ($ol) { Ok "Ollama instalado" }
    else {
      Aviso "Instálalo a mano: se abrirá la página de Ollama. Descarga la versión de Windows y ábrela."
      Start-Process "https://ollama.com/download/windows"
      Pausa "Cuando termines de instalarlo, pulsa Enter"
      $ol = Ruta-Ollama
    }
  }
  if ($ol) {
    $olApp = Join-Path (Split-Path $ol) "ollama app.exe"
    if (Test-Path $olApp) { Start-Process $olApp } else { Start-Process $ol -ArgumentList "serve" -WindowStyle Hidden }
    Start-Sleep -Seconds 6
    Info "Descargando el modelo gemma3:4b (unos 3,3 GB). Si se corta, se reanuda."
    Info "Puedes dejarlo trabajando: si se va la corriente, vuelve a ejecutar el instalador."
    $ok = $false
    for ($i = 1; $i -le 5 -and -not $ok; $i++) {
      & $ol pull gemma3:4b
      if ($LASTEXITCODE -eq 0) { $ok = $true } else { Aviso "Se cortó la descarga. Reintentando ($i de 5)..."; Start-Sleep -Seconds 10 }
    }
    if ($ok) { Ok "Modelo gemma3:4b listo: NexusIA puede trabajar sin Internet" } else { Aviso "No se completó. Más tarde ejecuta en PowerShell:  ollama pull gemma3:4b" }
  }
}

# ---------------------------------------------------------- final
Titulo "¡Listo! NexusIA está instalada"
Info "Ahora se abrirá NexusIA con el ASISTENTE DE CONFIGURACIÓN."
Info "Te guiará en 3 pasos:"
if ($op -in "1", "2") {
  Info "  1. Pegar la clave de FreeLLMAPI (clic derecho en su icono junto al reloj > Copy Key)."
  Info "  2. Añadir IA gratis con sus enlaces (recomendado: Gemini y Groq)."
} else {
  Info "  1. (Se salta: no instalaste FreeLLMAPI.)"
  Info "  2. Pegar claves gratis directamente en NexusIA (recomendado: Gemini y Groq)."
}
Info "  3. Prueba final."
Info ""
Info "En adelante, abre NexusIA con el icono «NexusIA» del escritorio."
Info "Guías en: $destino  (GUIA.md, CREAR-AGENTE.md, INSTALACION.md)"
Info "Ayuda por WhatsApp: +53 5508 1288"
try { Stop-Transcript | Out-Null } catch {}
Pausa "Pulsa Enter para abrir NexusIA"
Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Minimized", "-File", "`"$destino\Abrir-NexusIA.ps1`"", "-setup" -WorkingDirectory $destino
