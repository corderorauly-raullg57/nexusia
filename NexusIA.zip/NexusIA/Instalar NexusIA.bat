@echo off
title Instalar NexusIA
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-NexusIA.ps1"
if errorlevel 1 pause
