﻿# NexusIA - lanzador
# 1) Abre FreeLLMAPI y Ollama si estan instalados y cerrados
# 2) Sirve NexusIA en http://localhost y conecta las IA locales sin bloqueos del navegador
$puerto  = 31490
$carpeta = Split-Path -Parent $MyInvocation.MyCommand.Path
$html    = Join-Path $carpeta "nexus-ia.html"
$Host.UI.RawUI.WindowTitle = "NexusIA"

if (-not (Test-Path $html)) {
  Write-Host "No encuentro nexus-ia.html en esta carpeta: $carpeta" -ForegroundColor Red
  Read-Host "Pulsa Enter para cerrar"; exit
}

function Test-Puerto([int]$p) {
  try {
    $c = New-Object System.Net.Sockets.TcpClient
    $ok = $c.ConnectAsync("127.0.0.1", $p).Wait(600)
    $r = $ok -and $c.Connected; $c.Close(); return $r
  } catch { return $false }
}
function Get-FreePort {
  foreach ($p in 31415, 3001) { if (Test-Puerto $p) { return $p } }
  return 0
}
# Busca la clave de FreeLLMAPI en sus datos (para que NexusIA se configure sola)
function Get-FreeKeys {
  $out = @()
  try {
    $dirs = @("$env:APPDATA\FreeLLMAPI", "$env:APPDATA\freellmapi", "$env:LOCALAPPDATA\FreeLLMAPI", "$env:USERPROFILE\.freellmapi") | Where-Object { Test-Path $_ }
    foreach ($d in $dirs) {
      Get-ChildItem $d -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -lt 60MB -and $_.Extension -notmatch "^\.(exe|dll|png|jpg|ico|asar|node)$" } | Sort-Object LastWriteTime -Descending | ForEach-Object {
        try {
          $t = [Text.Encoding]::GetEncoding(28591).GetString([IO.File]::ReadAllBytes($_.FullName))
          foreach ($m in [regex]::Matches($t, "freellmapi-[A-Za-z0-9]{24,64}")) { if ($out -notcontains $m.Value) { $out += $m.Value } }
        } catch {}
      }
    }
  } catch {}
  return ($out | Select-Object -First 6)
}
$freeKeys = $null

function Find-App([string]$patron, [string[]]$rutas) {
  foreach ($r in $rutas) { if ($r -and (Test-Path $r)) { return $r } }
  $lugares = @("$env:USERPROFILE\Desktop", "$env:PUBLIC\Desktop", "$env:USERPROFILE\OneDrive\Desktop", "$env:USERPROFILE\OneDrive\Escritorio",
               "$env:APPDATA\Microsoft\Windows\Start Menu\Programs", "$env:ProgramData\Microsoft\Windows\Start Menu\Programs")
  foreach ($l in $lugares) {
    if (Test-Path $l) {
      $a = Get-ChildItem -Path $l -Recurse -Include "*.lnk", "*.exe" -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $patron } | Select-Object -First 1
      if ($a) { return $a.FullName }
    }
  }
  return $null
}

Write-Host ""
Write-Host "  NexusIA" -ForegroundColor Yellow

# --- FreeLLMAPI ---
if ((Get-FreePort) -eq 0) {
  $app = Find-App "free\s*llm" @("$env:LOCALAPPDATA\Programs\FreeLLMAPI\FreeLLMAPI.exe", "$env:LOCALAPPDATA\Programs\freellmapi\FreeLLMAPI.exe", "$env:ProgramFiles\FreeLLMAPI\FreeLLMAPI.exe")
  if ($app) {
    Write-Host "  Abriendo FreeLLMAPI..." -ForegroundColor Cyan
    Start-Process $app
    for ($i = 0; $i -lt 45 -and (Get-FreePort) -eq 0; $i++) { Start-Sleep -Seconds 1 }
  }
}
# --- Ollama ---
if (-not (Test-Puerto 11434)) {
  $olApp = "$env:LOCALAPPDATA\Programs\Ollama\ollama app.exe"
  $olExe = "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe"
  if (Test-Path $olApp) { Write-Host "  Abriendo Ollama..." -ForegroundColor Cyan; Start-Process $olApp }
  elseif (Test-Path $olExe) { Write-Host "  Abriendo Ollama..." -ForegroundColor Cyan; Start-Process $olExe -ArgumentList "serve" -WindowStyle Hidden }
  if ((Test-Path $olApp) -or (Test-Path $olExe)) { for ($i = 0; $i -lt 20 -and -not (Test-Puerto 11434); $i++) { Start-Sleep -Seconds 1 } }
}

$fp = Get-FreePort
if ($fp -gt 0) { Write-Host "  FreeLLMAPI conectado (puerto $fp)" -ForegroundColor Cyan } else { Write-Host "  FreeLLMAPI no esta abierto" -ForegroundColor DarkGray }
if (Test-Puerto 11434) { Write-Host "  Ollama conectado" -ForegroundColor Cyan } else { Write-Host "  Ollama no esta abierto (opcional)" -ForegroundColor DarkGray }

# --- Puerto propio (si lo usa otra app, prueba el siguiente) ---
$listener = $null
for ($intento = 0; $intento -lt 10; $intento++) {
  $p = $puerto + $intento
  $l = New-Object System.Net.HttpListener
  $l.Prefixes.Add("http://localhost:$p/")
  try { $l.Start(); $listener = $l; $puerto = $p; break } catch {
    $l.Close()
    $es = $false
    try { $es = ((Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 "http://localhost:$p/nexus-ping").Content -eq "nexus") } catch {}
    if ($es) { Write-Host "  NexusIA ya estaba abierta. Abriendo el navegador..." -ForegroundColor Yellow; Start-Process "http://localhost:$p/"; Start-Sleep 3; exit }
  }
}
if (-not $listener) { Write-Host "No encontre un puerto libre." -ForegroundColor Red; Read-Host "Pulsa Enter para cerrar"; exit }

$extra = ""
if ($args -contains "-setup") { $extra = "?setup=1" }
Start-Process "http://localhost:$puerto/$extra"
Write-Host ""
Write-Host "  NexusIA funcionando en http://localhost:$puerto" -ForegroundColor Green
Write-Host "  Puedes minimizar esta ventana, pero NO la cierres mientras uses NexusIA." -ForegroundColor Green
Write-Host ""

function Send-Text($res, [int]$code, [string]$type, [string]$text) {
  $b = [Text.Encoding]::UTF8.GetBytes($text)
  $res.StatusCode = $code; $res.ContentType = $type; $res.ContentLength64 = $b.Length
  $res.OutputStream.Write($b, 0, $b.Length)
}
function Forward($req, $res, [string]$url) {
  $fwd = [Net.HttpWebRequest]::Create($url)
  $fwd.Method = $req.HttpMethod; $fwd.Proxy = $null
  $fwd.Timeout = 600000; $fwd.ReadWriteTimeout = 600000
  if ($req.Headers["Authorization"]) { $fwd.Headers.Add("Authorization", $req.Headers["Authorization"]) }
  if ($req.HasEntityBody) {
    $fwd.ContentType = $req.ContentType
    $s = $fwd.GetRequestStream(); $req.InputStream.CopyTo($s); $s.Close()
  }
  $up = $null
  try { $up = $fwd.GetResponse() }
  catch {
    $ex = $_.Exception
    while ($ex -and -not ($ex -is [Net.WebException])) { $ex = $ex.InnerException }
    if ($ex -and $ex.Response) { $up = $ex.Response } else { throw }
  }
  $res.StatusCode = [int]$up.StatusCode
  if ($up.ContentType) { $res.ContentType = $up.ContentType }
  $res.SendChunked = $true
  $us = $up.GetResponseStream(); $buf = New-Object byte[] 8192
  while (($n = $us.Read($buf, 0, $buf.Length)) -gt 0) { $res.OutputStream.Write($buf, 0, $n); $res.OutputStream.Flush() }
  $up.Close()
  Write-Host ("  " + (Get-Date -Format "HH:mm:ss") + "  " + $req.HttpMethod + " " + $req.Url.AbsolutePath + " -> " + [int]$up.StatusCode)
}

while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $req = $ctx.Request
  $res = $ctx.Response
  try {
    $ruta = $req.Url.AbsolutePath
    if ($ruta -eq "/nexus-ping") { Send-Text $res 200 "text/plain" "nexus" }
    elseif ($ruta -eq "/nexus-status") {
      $fp = Get-FreePort
      $ol = Test-Puerto 11434
      if ($null -eq $freeKeys -and $fp -gt 0) { $freeKeys = @(Get-FreeKeys) }
      $kj = (@($freeKeys) | Where-Object { $_ } | ForEach-Object { '"' + $_ + '"' }) -join ","
      $json = '{"freellm":' + ($(if ($fp -gt 0) { "true" } else { "false" })) + ',"freellmPort":' + $fp + ',"ollama":' + ($(if ($ol) { "true" } else { "false" })) + ',"freellmKeys":[' + $kj + ']}'
      Send-Text $res 200 "application/json" $json
    }
    elseif ($ruta -eq "/" -or $ruta -eq "/nexus-ia.html") {
      $bytes = [IO.File]::ReadAllBytes($html)
      $res.ContentType = "text/html; charset=utf-8"; $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    }
    elseif ($ruta -match "^/(guia|GUIA)[^/]*\.html$" -and (Test-Path (Join-Path $carpeta $ruta.Substring(1)))) {
      $bytes = [IO.File]::ReadAllBytes((Join-Path $carpeta $ruta.Substring(1)))
      $res.ContentType = "text/html; charset=utf-8"; $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    }
    elseif ($ruta.StartsWith("/ollama/")) {
      if (-not (Test-Puerto 11434)) { Send-Text $res 503 "application/json" '{"error":{"message":"Ollama no esta abierto."}}' }
      else { Forward $req $res ("http://127.0.0.1:11434" + $req.Url.PathAndQuery.Substring(7)) }
    }
    elseif ($ruta.StartsWith("/v1/")) {
      $fp = Get-FreePort
      if ($fp -eq 0) { Send-Text $res 503 "application/json" '{"error":{"message":"FreeLLMAPI no esta abierto."}}' }
      else { Forward $req $res ("http://127.0.0.1:" + $fp + $req.Url.PathAndQuery) }
    }
    else { $res.StatusCode = 404 }
  }
  catch {
    Write-Host ("  Aviso: " + $_.Exception.Message) -ForegroundColor Yellow
    try { $res.StatusCode = 502 } catch {}
  }
  finally { try { $res.OutputStream.Close() } catch {} }
}
