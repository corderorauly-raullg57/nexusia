@echo off
title NexusIA
cd /d "%~dp0"
start "NexusIA" /min powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0Abrir-NexusIA.ps1"
